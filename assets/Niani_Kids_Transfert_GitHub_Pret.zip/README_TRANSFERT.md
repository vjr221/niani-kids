# Niani Kids — transfert graphique préparé

Ce paquet regroupe les visuels officiels du Pack Production Intégral V2, rangés dans des chemins de transfert adaptés au dépôt `vjr221/niani-kids`.

## Contenu
- `assets/brand/`: logo social, logo transparent, icône source, logo sur fond clair et bannière.
- `assets/characters/reference-boards/`: planches de références de personnages. Ces planches sont marquées comme références à valider dans le pack d'origine : elles ne doivent pas être utilisées comme portraits individuels définitifs sans validation.

## Import
Décompresser à la racine du dépôt `vjr221/niani-kids`, en conservant l'arborescence, puis valider le commit avant de modifier les références du site ou `app.json`.

## Important
`concept_icone_application.png` est le concept fourni, pas nécessairement un export final carré aux tailles requises par Expo/Android. Préparer/valider un export d'icône dédié avant une compilation de production.
